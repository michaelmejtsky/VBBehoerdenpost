# VB Behördenpost – PWA Launcher

Diese GitHub-Pages-PWA enthält ausschließlich die Launcher-Oberfläche und App-Icons.
Behördenpost-Daten und der Zugangscode werden hier nicht gespeichert.

Dateien:
- index.html
- manifest.json
- sw.js
- icon-192.png
- icon-512.png
